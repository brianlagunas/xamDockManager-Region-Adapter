﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.Prism.Regions;
using Infragistics.Windows.DockManager;

namespace XamDockManagerPrismRegionAdapter.Prism
{
    public class TabGroupPaneRegionAdapter : RegionAdapterBase<TabGroupPane>
    {
        public TabGroupPaneRegionAdapter(IRegionBehaviorFactory regionBehaviorFactory)
            : base(regionBehaviorFactory)
        {
        }

        protected override void Adapt(IRegion region, TabGroupPane regionTarget)
        {
            
        }

        protected override void AttachBehaviors(IRegion region, TabGroupPane regionTarget)
        {
            if (!region.Behaviors.ContainsKey(TabGroupPaneRegionBehavior.BehaviorKey))
            {
                region.Behaviors.Add(TabGroupPaneRegionBehavior.BehaviorKey, new TabGroupPaneRegionBehavior { HostControl = regionTarget });
            }

            base.AttachBehaviors(region, regionTarget);            
        }

        protected override IRegion CreateRegion()
        {
            return new Region();
        }
    }
}
